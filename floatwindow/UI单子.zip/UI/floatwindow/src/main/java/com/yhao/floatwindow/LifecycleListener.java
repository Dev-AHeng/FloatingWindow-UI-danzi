package com.yhao.floatwindow;

/**
 * Created by yhao on 2017/12/22.
 * https://github.com/yhaolpz
 */

interface LifecycleListener {

    void onShow();

    void onHide();

    void onBackToDesktop();
}
