package com.yhao.floatwindow;

/**
 * Created by yhao on 2017/11/14.
 * https://github.com/yhaolpz
 */
public interface PermissionListener {
    void onSuccess();

    void onFail();
}
