package aheng.ui;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.yhao.floatwindow.FloatWindow;
import com.yhao.floatwindow.PermissionListener;
import com.yhao.floatwindow.ViewStateListener;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * @author Dev_Heng
 */
public class MainActivity2 extends AppCompatActivity {
    private static final String TAG = "FloatWindow";
    
    public PermissionListener mPermissionListener = new PermissionListener() {
        @Override
        public void onSuccess() {
            Log.d(TAG, "onSuccess");
        }
        
        @Override
        public void onFail() {
            Log.d(TAG, "onFail");
        }
    };
    public ViewStateListener mViewStateListener = new ViewStateListener() {
        @Override
        public void onPositionUpdate(int x, int y) {
            Log.d(TAG, "onPositionUpdate: x=" + x + " y=" + y);
        }
        
        @Override
        public void onShow() {
            Log.d(TAG, "onShow");
        }
        
        @Override
        public void onHide() {
            Log.d(TAG, "onHide");
        }
        
        @Override
        public void onDismiss() {
            Log.d(TAG, "onDismiss");
        }
        
        @Override
        public void onMoveAnimStart() {
            Log.d(TAG, "onMoveAnimStart");
        }
        
        @Override
        public void onMoveAnimEnd() {
            Log.d(TAG, "onMoveAnimEnd");
        }
        
        @Override
        public void onBackToDesktop() {
            Log.d(TAG, "onBackToDesktop");
        }
    };
    private LayoutInflater layoutInflater;
    private View displayView;
    private TextView txv1, txv2;
    private Button button1, button2;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        
        Button btn = (Button) findViewById(R.id.activitymainButton1);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View p1) {
                openff();
            }
        });
        
    }
    
    private void openff() {
        
        layoutInflater = LayoutInflater.from(this);
        displayView = layoutInflater.inflate(R.layout.myfloat, null);
        
        FloatWindow
                .with(getApplicationContext())
                .setView(displayView)
                .setWidth(WindowManager.LayoutParams.WRAP_CONTENT) // 设置悬浮控件宽高
                .setHeight(WindowManager.LayoutParams.WRAP_CONTENT)
//            .setX(Screen.width, 0.8f)
//            .setY(Screen.height, 0.3f)
//            .setMoveType(MoveType.slide, 100, 100)
//            .setMoveStyle(500, new BounceInterpolator())
                // .setFilter(true, A_Activity.class, C_Activity.class)
                .setViewStateListener(mViewStateListener)
                .setPermissionListener(mPermissionListener)
                .setDesktopShow(true) // 桌面显示
                .build();
        
        
        txv1 = (TextView) displayView.findViewById(R.id.xfTextView1);
        txv2 = (TextView) displayView.findViewById(R.id.xfTextView2);
        
        button1 = (Button) displayView.findViewById(R.id.xfButton1);
        button2 = (Button) displayView.findViewById(R.id.xfButton2);
        
        
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 销毁
                // FloatWindow.destroy();
                // Toast.makeText(MainActivity.this, "取消", Toast.LENGTH_SHORT).show();
                
                ScheduledExecutorService scheduletwo = Executors.newSingleThreadScheduledExecutor();
                scheduletwo.scheduleAtFixedRate(new Runnable() {
                    @Override
                    public void run() {
                        
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                txv1.setText("随机数 -> " + (Math.random() * 10000));
                                txv2.setText("随机数 -> " + (Math.random() * 10000));
                            }
                        });
                    }
                    // 定时3秒后运行  运行5次  单位毫秒
                }, 0, 10, TimeUnit.MILLISECONDS);
                
            }
        });
        
        
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View p1) {
                // 销毁
                FloatWindow.destroy();
            }
        });
    }
    
}
