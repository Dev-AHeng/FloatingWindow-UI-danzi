package com.yhao.floatwindow;

/**
 * Created by yhao on 2018/5/5.
 * https://github.com/yhaolpz
 */
public class ViewStateListenerAdapter implements ViewStateListener{
    @Override
    public void onPositionUpdate(int x, int y) {

    }

    @Override
    public void onShow() {

    }

    @Override
    public void onHide() {

    }

    @Override
    public void onDismiss() {

    }

    @Override
    public void onMoveAnimStart() {

    }

    @Override
    public void onMoveAnimEnd() {

    }

    @Override
    public void onBackToDesktop() {

    }
}
