package aheng.ui;

import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * @author Dev_Heng
 */
public class MainActivity extends AppCompatActivity {
    private static final String TAG = "日志";
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        
        // 右边cardview
        CardView cardView2 = findViewById(R.id.cardView2);
        int w = View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED);
        int h = View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED);
        cardView2.measure(w, h);
        int width = cardView2.getMeasuredWidth();
        int height = cardView2.getMeasuredHeight();
        
        Log.i(TAG, height + "---" + width);
        
        // 左边cardview-->linearlayout
        LinearLayout ll = findViewById(R.id.left);
        ViewGroup.LayoutParams lp = ll.getLayoutParams();
        // lp.width = 0;
        lp.height = height;
        ll.setLayoutParams(lp);
    
        TextView textView = findViewById(R.id.date);
        Date date = new Date();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
        textView.setText(simpleDateFormat.format(date));
    }
    
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }
    
    
}